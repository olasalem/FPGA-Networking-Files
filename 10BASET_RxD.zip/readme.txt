To compile these files, be sure to also get the "async_transmitter.v" from here:
http://www.fpga4fun.com/files/async.zip